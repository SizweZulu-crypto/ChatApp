package chatapp.pkg1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Arrays {

    // Array for Sent Messages
    static ArrayList<String> sentMessages = new ArrayList<>();

    // Array for Disregarded Messages
    static ArrayList<String> disregardedMessages = new ArrayList<>();

    // Array for Stored Messages
    // These lists go together: position 0 in every list is the SAME message
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> storedIDs = new ArrayList<>();
    static ArrayList<String> storedHashes = new ArrayList<>();
    static ArrayList<String> storedRecipients = new ArrayList<>();
    static ArrayList<String> storedSenders = new ArrayList<>();

    // Message Hash and ID Arrays (every message).
    // These two lists and the next two go together: position 0 in each one is the
    // first message that was created, position 1 is the second, and so on.
    static ArrayList<String> messageHash = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> allMessages = new ArrayList<>();
    static ArrayList<String> allRecipients = new ArrayList<>();

    // ------------------------------------------------------------
    // Save all the stored messages into messages.json
    // ------------------------------------------------------------
    public static void saveToJson() {
        String file = "[\n";

        for (int i = 0; i < storedMessages.size(); i++) {
            file = file + "{\"sender\": \"" + storedSenders.get(i) + "\", "
                    + "\"messageID\": \"" + storedIDs.get(i) + "\", "
                    + "\"messageHash\": \"" + storedHashes.get(i) + "\", "
                    + "\"recipient\": \"" + storedRecipients.get(i) + "\", "
                    + "\"message\": \"" + storedMessages.get(i) + "\"}";

            // put a comma after every message except the last one
            if (i < storedMessages.size() - 1) {
                file = file + ",";
            }
            file = file + "\n";
        }

        file = file + "]";

        try {
            Files.writeString(Path.of("messages.json"), file);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------
    // Read messages.json back into the stored lists
    // ------------------------------------------------------------
    public static void loadFromJson() {
        // empty the lists first so nothing is added twice
        storedMessages.clear();
        storedIDs.clear();
        storedHashes.clear();
        storedRecipients.clear();
        storedSenders.clear();

        // if the file does not exist yet, there is nothing to read
        if (!Files.exists(Path.of("messages.json"))) {
            return;
        }

        try {
            List<String> lines = Files.readAllLines(Path.of("messages.json"));

            for (int i = 0; i < lines.size(); i++) {

                // Every message is one line. Cutting the line at every quote mark (")
                // gives us pieces, and the pieces we want are always in the same place:
                //   parts[3] = sender      parts[7] = message ID    parts[11] = hash
                //   parts[15] = recipient  parts[19] = message
                String[] parts = lines.get(i).split("\"");

                // lines like [ and ] are too short, so we skip them
                if (parts.length >= 20) {
                    storedSenders.add(parts[3]);
                    storedIDs.add(parts[7]);
                    storedHashes.add(parts[11]);
                    storedRecipients.add(parts[15]);
                    storedMessages.add(parts[19]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Empty all the lists (the unit tests use this to start fresh)
    public static void clearAll() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        storedIDs.clear();
        storedHashes.clear();
        storedRecipients.clear();
        storedSenders.clear();
        messageHash.clear();
        messageIDs.clear();
        allMessages.clear();
        allRecipients.clear();
    }

    // ------------------------------------------------------------
    // a. Display the sender and recipient of all stored messages
    // ------------------------------------------------------------
    public static String displaySenderAndRecipient() {
        if (storedMessages.size() == 0) {
            return "There are no stored messages.";
        }

        String result = "";
        for (int i = 0; i < storedMessages.size(); i++) {
            result = result + "Sender: " + storedSenders.get(i)
                    + " | Recipient: " + storedRecipients.get(i) + "\n";
        }
        return result;
    }

    // ------------------------------------------------------------
    // b. Display the longest stored message
    // ------------------------------------------------------------
    public static String displayLongestMessage() {
        if (storedMessages.size() == 0) {
            return "There are no stored messages.";
        }

        String longest = "";
        for (int i = 0; i < storedMessages.size(); i++) {
            // if this message is longer than the longest so far, it becomes the longest
            if (storedMessages.get(i).length() > longest.length()) {
                longest = storedMessages.get(i);
            }
        }
        return longest;
    }

    // ------------------------------------------------------------
    // c. Search for a message ID and display the recipient and message
    // (this looks through EVERY message, not only the stored ones)
    // ------------------------------------------------------------
    public static String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return allMessages.get(i);
            }
        }
        return "Message ID not found.";
    }

    public static String searchRecipientByID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return allRecipients.get(i);
            }
        }
        return "Message ID not found.";
    }

    // ------------------------------------------------------------
    // d. Search for all the messages stored for a recipient
    // ------------------------------------------------------------
    public static String searchByRecipient(String recipient) {
        String result = "";

        for (int i = 0; i < storedRecipients.size(); i++) {
            if (storedRecipients.get(i).equals(recipient)) {
                result = result + storedMessages.get(i) + "\n";
            }
        }

        if (result.equals("")) {
            return "No stored messages found for that recipient.";
        }
        return result;
    }

    // ------------------------------------------------------------
    // e. Delete a message using the message hash
    // ------------------------------------------------------------
    public static String deleteByHash(String hash) {
        for (int i = 0; i < storedHashes.size(); i++) {
            if (storedHashes.get(i).equals(hash)) {
                String deletedText = storedMessages.get(i);

                // remove position i from ALL five stored lists so they stay matched
                storedMessages.remove(i);
                storedIDs.remove(i);
                storedHashes.remove(i);
                storedRecipients.remove(i);
                storedSenders.remove(i);

                // remove it from the "every message" lists too
                for (int j = 0; j < messageHash.size(); j++) {
                    if (messageHash.get(j).equals(hash)) {
                        messageHash.remove(j);
                        messageIDs.remove(j);
                        allMessages.remove(j);
                        allRecipients.remove(j);
                        break;
                    }
                }

                saveToJson();     // update the file too
                return "Message: \"" + deletedText + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // ------------------------------------------------------------
    // f. Display a report of all the stored messages
    // ------------------------------------------------------------
    public static String displayReport() {
        if (storedMessages.size() == 0) {
            return "There are no stored messages.";
        }

        String report = "";
        for (int i = 0; i < storedMessages.size(); i++) {
            report = report + "Message ID: " + storedIDs.get(i) + "\n"
                    + "Message Hash: " + storedHashes.get(i) + "\n"
                    + "Sender: " + storedSenders.get(i) + "\n"
                    + "Recipient: " + storedRecipients.get(i) + "\n"
                    + "Message: " + storedMessages.get(i) + "\n\n";
        }
        return report;
    }

    // ------------------------------------------------------------
    // The Stored Messages menu (main menu option 4)
    // ------------------------------------------------------------
    public static void storedMessagesMenu(Scanner scan) {
        int choice = 0;

        while (choice != 7) {
            System.out.println("\nStored Messages");
            System.out.println("1) Display the sender and recipient of all stored messages");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message ID");
            System.out.println("4) Search for all messages stored for a recipient");
            System.out.println("5) Delete a message using the message hash");
            System.out.println("6) Display a report of all stored messages");
            System.out.println("7) Back to the main menu");
            choice = scan.nextInt();
            scan.nextLine();

            if (choice == 1) {
                System.out.println(displaySenderAndRecipient());
            } else if (choice == 2) {
                System.out.println(displayLongestMessage());
            } else if (choice == 3) {
                System.out.println("Enter the message ID:");
                String id = scan.nextLine();
                System.out.println("Recipient: " + searchRecipientByID(id));
                System.out.println("Message: " + searchByMessageID(id));
            } else if (choice == 4) {
                System.out.println("Enter the recipient's cell number:");
                String recipient = scan.nextLine();
                System.out.println(searchByRecipient(recipient));
            } else if (choice == 5) {
                System.out.println("Enter the message hash:");
                String hash = scan.nextLine();
                System.out.println(deleteByHash(hash));
            } else if (choice == 6) {
                System.out.println(displayReport());
            }
        }
    }
}