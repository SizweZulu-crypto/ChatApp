package chatapp.pkg1;

import java.util.Random;
import java.util.Scanner;

/**
 * One chat message plus the QuickChat menu.
 * The arrays live in the Arrays class, so this class calls Arrays.something().
 */
public class Message {

    // Details of ONE message
    String messageID;
    int messageNumber;
    String recipient;
    String message;

    // The person who is logged in and sending the messages
    static String sender = "";

    // The constructor must have the SAME name as the class (capital M)
    public Message(String recipient, String message) {
        this.recipient = recipient;
        this.message = message;

        // message number = how many messages were sent before this one (first message = 0)
        this.messageNumber = Arrays.sentMessages.size();

        // random 10-digit ID: add one random digit (0-9) ten times
        Random random = new Random();
        messageID = "";
        for (int i = 0; i < 10; i++) {
            messageID = messageID + random.nextInt(10);
        }
    }

    // The ID must be no more than 10 characters
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // The number must be +27 followed by 9 digits.
    // The regex is a pattern: \\+27 = "+27", [0-9]{9} = exactly 9 digits.
    public boolean checkRecipientCell(String cellphone) {
        String regex = "\\+27[0-9]{9}";

        return cellphone.matches(regex);
    }

    // The message must not be more than 250 characters
    public String checkMessageLength() {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int tooMany = message.length() - 250;
            return "Message exceeds 250 characters by " + tooMany + "; please reduce the size.";
        }
    }

    // Hash = first 2 digits of the ID : message number : FIRSTWORD + LASTWORD
    public String createMessageHash() {
        String text = message.trim();
        String firstWord;
        String lastWord;

        int firstSpace = text.indexOf(" ");          // position of the first space (-1 = none)
        if (firstSpace == -1) {
            // only one word in the message
            firstWord = text;
            lastWord = text;
        } else {
            firstWord = text.substring(0, firstSpace);
            lastWord = text.substring(text.lastIndexOf(" ") + 1);
        }

        String hash = messageID.substring(0, 2) + ":" + messageNumber + ":" + firstWord + lastWord;

        // remove punctuation
        hash = hash.replace(",", "").replace(".", "").replace("!", "").replace("?", "");
        return hash.toUpperCase();
    }

    // Full details: ID, Hash, Recipient, Message
    public String getDetails() {
        return "Message ID: " + messageID + "\n"
                + "Message Hash: " + createMessageHash() + "\n"
                + "Recipient: " + recipient + "\n"
                + "Message: " + message;
    }

    // 1 = send, 2 = disregard, 3 = store. Each choice adds the message to its own array.
    public String sentMessage(int choice) {
        if (choice == 1) {
            Arrays.sentMessages.add(message);
            addToAllLists();
            return "Message successfully sent.";
        } else if (choice == 2) {
            Arrays.disregardedMessages.add(message);
            addToAllLists();
            return "Press 0 to delete the message.";
        } else if (choice == 3) {
            storeMessage();
            addToAllLists();
            return "Message successfully stored.";
        } else {
            return "Please enter the correct option.";
        }
    }

    // Add this message to the "every message" lists (ID, hash, text and recipient)
    private void addToAllLists() {
        Arrays.messageIDs.add(messageID);
        Arrays.messageHash.add(createMessageHash());
        Arrays.allMessages.add(message);
        Arrays.allRecipients.add(recipient);
    }

    // Add this message to the Stored arrays, then save them to the JSON file
    private void storeMessage() {
        // a " inside the text would break the JSON, so we change it to '
        Arrays.storedMessages.add(message.replace("\"", "'"));
        Arrays.storedIDs.add(messageID);
        Arrays.storedHashes.add(createMessageHash());
        Arrays.storedRecipients.add(recipient);
        Arrays.storedSenders.add(sender);

        Arrays.saveToJson();
    }

    // Every message that was sent (one per line)
    public static String printMessages() {
        String all = "";
        for (String m : Arrays.sentMessages) {
            all = all + m + "\n";
        }
        return all;
    }

    // How many messages were sent
    public static int returnTotalMessages() {
        return Arrays.sentMessages.size();
    }

    // ------------------------------------------------------------
    // The QuickChat menu. ChatApp1 calls this after a successful login:
    //     Message.quickChat();
    // ------------------------------------------------------------
    public static void quickChat() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Welcome to QuickChat.");
        System.out.println("Enter your username:");
        sender = scan.nextLine();

        // read the JSON file into the stored arrays
        Arrays.loadFromJson();

        System.out.println("How many messages do you want to enter?");
        int max = scan.nextInt();
        scan.nextLine();

        int entered = 0;
        int option = 0;

        while (option != 3) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            option = scan.nextInt();
            scan.nextLine();

            if (option == 1) {
                if (entered >= max) {
                    System.out.println("You have already entered all " + max + " messages.");
                } else {
                    // keep asking until the number and the message are both fine
                    Message m;
                    boolean valid = false;
                    do {
                        System.out.println("Enter the recipient's cell number:");
                        String recipient = scan.nextLine();
                        System.out.println("Enter your message:");
                        String text = scan.nextLine();

                        m = new Message(recipient, text);
                        boolean cellOk = m.checkRecipientCell(recipient);
                        String lengthCheck = m.checkMessageLength();

                        if (cellOk) {
                            System.out.println("Cell phone number successfully captured.");
                        } else {
                            System.out.println("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.");
                        }
                        System.out.println(lengthCheck);

                        valid = cellOk && lengthCheck.equals("Message ready to send.");
                    } while (!valid);

                    System.out.println("Message ID generated: " + m.messageID);
                    System.out.println("Which action would you like to perform:");
                    System.out.println("1. Send Message");
                    System.out.println("2. Delete Message");
                    System.out.println("3. Store Message");
                    int choice = scan.nextInt();
                    scan.nextLine();

                    System.out.println(m.sentMessage(choice));

                    if (choice == 1) {
                        System.out.println(m.getDetails());
                    } else if (choice == 2) {
                        int zero = scan.nextInt();
                        scan.nextLine();
                        if (zero == 0) {
                            System.out.println("Message deleted successfully");
                        }
                    }
                    entered = entered + 1;
                }
            } else if (option == 2) {
                System.out.println("Coming Soon.");
            } else if (option == 4) {
                Arrays.storedMessagesMenu(scan);
            }
        }

        System.out.println("The total number of messages sent: " + returnTotalMessages());
    }
}