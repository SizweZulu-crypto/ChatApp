import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ArraysTest {

    // Replace 'MessageManager' with the actual class name handling your message arrays
    private MessageManager messageApp;

    @BeforeEach
    public void setUp() {
        messageApp = new MessageManager();
        
        // Developer entry for Test Data (Messages 1 - 4)
        // Adjust parameters to match your method signature (e.g., messageID, recipient, content, hash, status)
        messageApp.addMessage("MSG01", "+27834557896", "Did you get the cake?", "HASH1", "Sent");
        messageApp.addMessage("MSG02", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "HASH2", "Stored");
        messageApp.addMessage("MSG03", "+27834484567", "Yohoooo, I am at your gate.", "HASH3", "Disregarded");
        messageApp.addMessage("0838884567", "+27838884567", "It is dinner time!", "HASH4", "Sent");
        // Note: Add Test Message 5 if your search-by-recipient test relies on it[cite: 1]
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        // Verifies that the Sent Messages array contains the expected test data[cite: 1]
        String[] expectedSent = {"Did you get the cake?", "It is dinner time!"};
        String[] actualSent = messageApp.getSentMessages();
        
        assertArrayEquals(expectedSent, actualSent);
    }

    @Test
    public void testDisplayLongestMessage() {
        // Verifies the longest message across messages 1-4 is returned[cite: 1]
        String expected = "Where are you? You are late! I have asked you to be on time.";
        String actual = messageApp.getLongestMessage();
        
        assertEquals(expected, actual);
    }

    @Test
    public void testSearchByMessageID() {
        // Searches for messageID "0838884567" (Test Data: message 4)[cite: 1]
        String expected = "It is dinner time!";
        String actual = messageApp.searchByMessageID("0838884567");
        
        assertEquals(expected, actual);
    }

    @Test
    public void testSearchMessagesByRecipient() {
        // Searches all messages sent or stored regarding recipient +27838884567[cite: 1]
        String[] expected = {
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you."
        };
        String[] actual = messageApp.searchByRecipient("+27838884567");
        
        assertArrayEquals(expected, actual);
    }

    @Test
    public void testDeleteMessageByHash() {
        // Deletes Test Message 2 using its message hash[cite: 1]
        String expected = "Message \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.";
        String actual = messageApp.deleteMessageByHash("HASH2");
        
        assertEquals(expected, actual);
    }

    @Test
    public void testDisplayReport() {
        // Verifies the report contains Message Hash, Recipient, and Message for all sent messages[cite: 1]
        String report = messageApp.displayReport();
        
        assertTrue(report.contains("HASH1"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("HASH4"));
        assertTrue(report.contains("It is dinner time!"));
    }
}